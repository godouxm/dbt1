#!/bin/sh

psql -d $SID1 -f /home/pgsql/dbt1-v2.1/scripts/pgsql/create_tables.sql
psql -d $SID1 -c "GRANT ALL PRIVILEGES ON TABLE address, author, cc_xacts, country, customer, item, order_line, orders, shopping_cart, shopping_cart_line TO PUBLIC"
psql -d $SID1 -c "GRANT ALL PRIVILEGES ON TABLE addrid TO PUBLIC"
psql -d $SID1 -c "GRANT ALL PRIVILEGES ON TABLE scid TO PUBLIC"
psql -d $SID1 -c "GRANT ALL PRIVILEGES ON TABLE custid TO PUBLIC"
