#! /bin/sh

# create_db.sh
#
# This file is released under the terms of the Artistic License.  Please see
# the file LICENSE, included in this package, for details.
#
# Copyright (C) 2002 Open Source Development Lab, Inc.
#
# History:
# Aug-2003: Jenny Zhang

db_param=$1

/home/pgsql/dbt1-v2.1/scripts/pgsql/set_db_env.sh "$db_param"
/home/pgsql/dbt1-v2.1/scripts/pgsql/drop_db.sh

# create database
echo "create database $SID1..."
_o=`createdb $SID1 2>&1`
_test=`echo $_o | grep CREATE`
if [ "$_test" = "" ]; then
	echo "create $SID1 failed: $_o $_test"
	exit 1
fi

exit 0
