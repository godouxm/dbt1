psql -d $SID1 -f /home/pgsql/dbt1-v2.1/scripts/pgsql/create_indexes.sql
