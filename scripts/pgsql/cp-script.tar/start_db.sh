db_param=$1
if [ ! -d /home/pgsql/dbt1-v2.1/run ]; then
	mkdir /home/pgsql/dbt1-v2.1/run
fi
pg_ctl start -l /home/pgsql/dbt1-v2.1/run/db_logfile.txt -o ' $db_param '
sleep 10
